NSS is a database operation module made by Nanshan team.
It is simple and fast to use nssql.
The module can create database, create list, read database, change database, associate operation, import and export.
Functions included in this module: 
new_sql(sql_name='default_sql',password='None',existet=False): create a new database 
cursor(name=1): create cursor 
new_list(sql_name='default_sql',list_name='list0',existet=False,password='None'): create list 
new_position(sql_name='default_sql',list_name='list0',position_name='position0',data='NanShanSQL',password='None'): create location and add data 
close_sql(sql='default_sql'): close the database to open a new database 
open_sql(sql='default_sql',password='None'): get the contents of the database 
change_sql(sql_name='default_sql',list_name='list0',position_name='position0',new_data='NanShanSQL',password='None'): change the contents of the database 
change_password(sql='default_sql',new_password='None'): if there is a password, this function can change the password 
new_relation(sql='default_sql',obj1='default_sql\\list0\\position0',obj2='default_sql\\list1\\position0',password='None'): create a new relation 
open_relation(sql='default_sql',obj='default_sql\\list0\\position0',password='None'): open the data corresponding to the Association 
del_sql(sql_name='default_sql',password='None'): delete database 
export_sql(ea='nssea',sql_name='default_sql',file_position='D:\\',password='None'): export the database to a file 
import_sql(file='D:\\default_sql.nss',sql_name='default_sql',existet=False,password='None'): import the database file 
del_every_sql(): delete all databases